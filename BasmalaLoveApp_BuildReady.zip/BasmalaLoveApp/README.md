# Basmala Love Story (Android)

A romantic Android WebView app for Basmala, with a PIN screen (`2810`), seven bundled photos, a pink theme, local photo/memory additions, timeline, love letter, and an Enta Omri YouTube button.

See `README_AR.txt` for Arabic setup/build instructions.

This is the Android Studio source project, not a prebuilt APK. Build a debug APK in Android Studio using **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
